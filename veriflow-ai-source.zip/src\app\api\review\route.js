import prisma from '@/lib/db';
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const verifications = await prisma.verification.findMany({
      where: {
        status: {
          in: ['FLAGGED', 'UNDER_REVIEW']
        }
      }
    });
    
    const invoiceIds = verifications.map(v => v.invoiceId);
    const poIds = verifications.map(v => v.poId);
    
    const documents = await prisma.document.findMany({
      where: {
        id: { in: [...new Set([...invoiceIds, ...poIds])] }
      }
    });
    
    const result = verifications.map(v => ({
      ...v,
      invoice: documents.find(d => d.id === v.invoiceId),
      po: documents.find(d => d.id === v.poId)
    }));
    
    return NextResponse.json(result);
  } catch (error) {
    console.error('Error fetching reviews:', error);
    return NextResponse.json({ error: 'Failed to fetch reviews' }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const { verificationId, action, actor, comments } = await request.json();
    
    let newStatus;
    if (action === 'APPROVE') newStatus = 'APPROVED';
    else if (action === 'REJECT') newStatus = 'REJECTED';
    else if (action === 'REVIEW') newStatus = 'UNDER_REVIEW';
    else return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    
    const verification = await prisma.verification.update({
      where: { id: verificationId },
      data: { status: newStatus }
    });
    
    await prisma.auditLog.create({
      data: {
        verificationId,
        action,
        actor,
        details: comments || `Verification ${action.toLowerCase()}d`,
        metadata: JSON.stringify({ comments })
      }
    });
    
    return NextResponse.json(verification);
  } catch (error) {
    console.error('Error updating review:', error);
    return NextResponse.json({ error: 'Failed to update review' }, { status: 500 });
  }
}
