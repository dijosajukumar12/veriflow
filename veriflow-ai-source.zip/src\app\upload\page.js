'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { UploadCloud, FileText, Check, ChevronRight, Loader2, AlertCircle } from 'lucide-react';

export default function UploadPage() {
  const router = useRouter();
  const [invoice, setInvoice] = useState(null);
  const [po, setPo] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [step, setStep] = useState(0);

  const steps = ['Uploading files...', 'Extracting data...', 'Comparing documents...', 'Calculating risk score...'];

  const handleDrop = (e, type) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) {
      type === 'INVOICE' ? setInvoice(file) : setPo(file);
    }
  };

  const handleFileChange = (e, type) => {
    const file = e.target.files[0];
    if (file) {
      type === 'INVOICE' ? setInvoice(file) : setPo(file);
    }
  };

  const handleVerify = async () => {
    if (!invoice || !po) return;
    
    setIsProcessing(true);
    
    try {
      setStep(0);
      
      // 1. Upload Invoice
      const invFormData = new FormData();
      invFormData.append('file', invoice);
      invFormData.append('type', 'INVOICE');
      const invRes = await fetch('/api/documents', {
        method: 'POST',
        body: invFormData
      });
      if (!invRes.ok) throw new Error('Failed to upload invoice');
      const invDoc = await invRes.json();
      
      setStep(1);
      
      // 2. Upload PO
      const poFormData = new FormData();
      poFormData.append('file', po);
      poFormData.append('type', 'PURCHASE_ORDER');
      const poRes = await fetch('/api/documents', {
        method: 'POST',
        body: poFormData
      });
      if (!poRes.ok) throw new Error('Failed to upload PO');
      const poDoc = await poRes.json();
      
      setStep(2);
      
      // 3. Verify
      const verifyRes = await fetch('/api/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          invoiceId: invDoc.id,
          poId: poDoc.id
        })
      });
      if (!verifyRes.ok) throw new Error('Failed to verify documents');
      const verification = await verifyRes.json();
      
      setStep(3);
      await new Promise(resolve => setTimeout(resolve, 500)); // Short pause for animation

      // Redirect to the actual verification page
      router.push(`/verification/${verification.id}`);
    } catch (error) {
      console.error('Error during upload and verification:', error);
      setIsProcessing(false);
      alert('An error occurred during verification. Please try again.');
    }
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Upload & Verify</h1>
        <p className="page-subtitle">Upload invoice and purchase order for comparison</p>
      </div>

      {!isProcessing ? (
        <div className="card">
          <div className="grid grid-cols-2 gap-6">
            <div 
              className="upload-zone"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => handleDrop(e, 'INVOICE')}
              onClick={() => document.getElementById('invoice-input').click()}
            >
              <input 
                type="file" 
                id="invoice-input" 
                className="hidden" 
                style={{display: 'none'}}
                accept=".pdf,.png,.jpg"
                onChange={(e) => handleFileChange(e, 'INVOICE')}
              />
              <UploadCloud size={48} className="upload-icon mx-auto" />
              <h3 className="font-semibold text-lg mb-2">Upload Invoice</h3>
              <p className="text-secondary text-sm mb-4">Drag and drop or click to browse</p>
              {invoice && (
                <div className="mt-4 p-3 bg-blue-50 text-blue-700 rounded-lg flex items-center justify-center gap-2">
                  <FileText size={18} />
                  <span className="font-medium truncate max-w-[200px]">{invoice.name}</span>
                  <Check size={18} className="text-emerald-500" />
                </div>
              )}
            </div>

            <div 
              className="upload-zone"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => handleDrop(e, 'PO')}
              onClick={() => document.getElementById('po-input').click()}
            >
              <input 
                type="file" 
                id="po-input" 
                className="hidden"
                style={{display: 'none'}} 
                accept=".pdf,.png,.jpg"
                onChange={(e) => handleFileChange(e, 'PO')}
              />
              <UploadCloud size={48} className="upload-icon mx-auto" />
              <h3 className="font-semibold text-lg mb-2">Upload Purchase Order</h3>
              <p className="text-secondary text-sm mb-4">Drag and drop or click to browse</p>
              {po && (
                <div className="mt-4 p-3 bg-blue-50 text-blue-700 rounded-lg flex items-center justify-center gap-2">
                  <FileText size={18} />
                  <span className="font-medium truncate max-w-[200px]">{po.name}</span>
                  <Check size={18} className="text-emerald-500" />
                </div>
              )}
            </div>
          </div>

          <div className="mt-8 flex justify-end">
            <button 
              className="btn btn-primary"
              disabled={!invoice || !po}
              onClick={handleVerify}
            >
              Verify Documents <ChevronRight size={18} />
            </button>
          </div>
        </div>
      ) : (
        <div className="card max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <div className="inline-block p-4 bg-blue-50 rounded-full mb-4 text-primary">
              <Loader2 size={48} className="animate-spin" />
            </div>
            <h2 className="text-xl font-bold">Analyzing Documents</h2>
            <p className="text-secondary">Please wait while VeriFlow AI processes your files.</p>
          </div>

          <div className="max-w-md mx-auto">
            {steps.map((s, index) => (
              <div 
                key={index} 
                className={`step-indicator ${index === step ? 'active' : index < step ? 'completed' : ''}`}
              >
                <div className="step-icon">
                  {index < step ? <Check size={14} /> : index === step ? <Loader2 size={14} className="animate-spin" /> : ''}
                </div>
                <span>{s}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
