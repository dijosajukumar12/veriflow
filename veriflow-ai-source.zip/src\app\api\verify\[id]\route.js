import prisma from '@/lib/db';
import { NextResponse } from 'next/server';

export async function GET(request, { params }) {
  try {
    const { id } = params;
    const verification = await prisma.verification.findUnique({
      where: { id }
    });
    
    if (!verification) {
      return NextResponse.json({ error: 'Verification not found' }, { status: 404 });
    }
    
    const invoice = await prisma.document.findUnique({ where: { id: verification.invoiceId } });
    const po = await prisma.document.findUnique({ where: { id: verification.poId } });
    
    const auditLogs = await prisma.auditLog.findMany({
      where: { verificationId: id },
      orderBy: { timestamp: 'desc' }
    });
    
    return NextResponse.json({
      ...verification,
      invoice,
      po,
      comparisonResults: verification.comparisonResults ? JSON.parse(verification.comparisonResults) : null,
      riskFactors: verification.riskFactors ? JSON.parse(verification.riskFactors) : null,
      auditLogs
    });
  } catch (error) {
    console.error('Error fetching verification:', error);
    return NextResponse.json({ error: 'Failed to fetch verification' }, { status: 500 });
  }
}
