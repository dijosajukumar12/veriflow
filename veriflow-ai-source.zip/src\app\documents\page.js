'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Search, Filter, Eye } from 'lucide-react';

export default function DocumentsPage() {
  const [loading, setLoading] = useState(true);
  const [docs, setDocs] = useState([]);
  const [filter, setFilter] = useState('ALL');

  useEffect(() => {
    setTimeout(() => {
      setDocs([
        { id: 'v-12345', type: 'PAIR', invName: 'INV-2023-001.pdf', poName: 'PO-99234.pdf', status: 'VERIFIED', date: 'Aug 21, 2026, 10:30 AM' },
        { id: 'v-12346', type: 'PAIR', invName: 'INV-2023-002.pdf', poName: 'PO-99235.pdf', status: 'FLAGGED', date: 'Aug 21, 2026, 09:15 AM' },
        { id: 'v-12347', type: 'PAIR', invName: 'INV-2023-003.pdf', poName: 'PO-99236.pdf', status: 'UNDER_REVIEW', date: 'Aug 20, 2026, 16:45 PM' },
        { id: 'v-12348', type: 'PAIR', invName: 'INV-2023-004.pdf', poName: 'PO-99237.pdf', status: 'VERIFIED', date: 'Aug 20, 2026, 14:20 PM' },
      ]);
      setLoading(false);
    }, 800);
  }, []);

  const getStatusBadge = (status) => {
    switch(status) {
      case 'VERIFIED': return <span className="badge badge-success">Verified</span>;
      case 'FLAGGED': return <span className="badge badge-danger">Flagged</span>;
      case 'UNDER_REVIEW': return <span className="badge badge-warning">Under Review</span>;
      default: return <span className="badge badge-neutral">{status}</span>;
    }
  };

  return (
    <div>
      <div className="page-header flex justify-between items-end">
        <div>
          <h1 className="page-title">Documents</h1>
          <p className="page-subtitle">View and manage processed documents</p>
        </div>
        <div className="flex gap-2">
          <button className={`btn ${filter === 'ALL' ? 'btn-primary' : 'btn-outline'}`} onClick={() => setFilter('ALL')}>All</button>
          <button className={`btn ${filter === 'VERIFIED' ? 'btn-primary' : 'btn-outline'}`} onClick={() => setFilter('VERIFIED')}>Verified</button>
          <button className={`btn ${filter === 'FLAGGED' ? 'btn-primary' : 'btn-outline'}`} onClick={() => setFilter('FLAGGED')}>Flagged</button>
        </div>
      </div>

      <div className="card p-0 overflow-hidden">
        <div className="p-4 border-b flex justify-between items-center" style={{borderColor: 'var(--border)'}}>
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary" size={18} />
            <input type="text" placeholder="Search documents..." className="form-input pl-10" />
          </div>
          <button className="btn btn-outline"><Filter size={18} /> Filter</button>
        </div>

        {loading ? (
          <div className="p-6">
            {[1,2,3,4].map(i => <div key={i} className="skeleton skeleton-text mb-4" style={{height: 40}}></div>)}
          </div>
        ) : (
          <div className="table-container border-0 border-radius-0">
            <table>
              <thead>
                <tr>
                  <th>Verify ID</th>
                  <th>Documents</th>
                  <th>Status</th>
                  <th>Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {docs.filter(d => filter === 'ALL' || d.status === filter).map(doc => (
                  <tr key={doc.id}>
                    <td className="font-medium text-sm">{doc.id}</td>
                    <td>
                      <div className="text-sm font-medium">{doc.invName}</div>
                      <div className="text-xs text-secondary mt-1">vs {doc.poName}</div>
                    </td>
                    <td>{getStatusBadge(doc.status)}</td>
                    <td className="text-sm text-secondary">{doc.date}</td>
                    <td>
                      <Link href={`/verification/${doc.id}`} className="btn btn-outline" style={{padding: '6px 12px', fontSize: '0.8rem'}}>
                        <Eye size={14} /> View
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
