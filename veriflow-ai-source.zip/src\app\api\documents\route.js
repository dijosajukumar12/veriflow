import prisma from '@/lib/db';
import { NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { extractDocument } from '@/lib/extraction/extractor';

export async function GET() {
  try {
    const documents = await prisma.document.findMany({
      orderBy: { createdAt: 'desc' },
    });
    
    const verifications = await prisma.verification.findMany();
    
    const docsWithVerifications = documents.map(doc => ({
      ...doc,
      verifications: verifications.filter(v => v.invoiceId === doc.id || v.poId === doc.id)
    }));
    
    return NextResponse.json(docsWithVerifications);
  } catch (error) {
    console.error('Error fetching documents:', error);
    return NextResponse.json({ error: 'Failed to fetch documents' }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const formData = await request.formData();
    const file = formData.get('file');
    const type = formData.get('type');
    
    if (!file || !type) {
      return NextResponse.json({ error: 'File and type are required' }, { status: 400 });
    }
    
    const buffer = Buffer.from(await file.arrayBuffer());
    const originalFilename = file.name;
    const filename = `${uuidv4()}-${originalFilename}`;
    const uploadDir = path.join(process.cwd(), 'public', 'uploads');
    
    await fs.mkdir(uploadDir, { recursive: true });
    const filePath = path.join(uploadDir, filename);
    await fs.writeFile(filePath, buffer);
    
    // Extract text and data using our engines
    let rawText = '';
    let extractedData = {};
    
    try {
      const result = await extractDocument(buffer, type);
      rawText = result.rawText || '';
      extractedData = result.extractedData || {};
    } catch (extractErr) {
      console.error('Extraction failed (fallback to empty):', extractErr);
    }
    
    const document = await prisma.document.create({
      data: {
        type,
        filename: originalFilename,
        filePath: `/uploads/${filename}`,
        status: 'PROCESSED',
        rawText,
        extractedData: JSON.stringify(extractedData)
      }
    });
    
    return NextResponse.json(document);
  } catch (error) {
    console.error('Error uploading document:', error);
    return NextResponse.json({ error: 'Failed to upload document' }, { status: 500 });
  }
}
