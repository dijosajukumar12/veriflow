import prisma from '@/lib/db';
import { NextResponse } from 'next/server';
import { compareInvoiceWithPO } from '@/lib/comparison/engine';
import { calculateRiskScore } from '@/lib/risk/scorer';
import { generateExplanation } from '@/lib/explanation/generator';

export async function POST(request) {
  try {
    const { invoiceId, poId } = await request.json();
    
    const invoice = await prisma.document.findUnique({ where: { id: invoiceId } });
    const po = await prisma.document.findUnique({ where: { id: poId } });
    
    if (!invoice || !po) {
      return NextResponse.json({ error: 'Invoice or PO not found' }, { status: 404 });
    }
    
    const invoiceData = invoice.extractedData ? JSON.parse(invoice.extractedData) : {};
    const poData = po.extractedData ? JSON.parse(po.extractedData) : {};
    
    const comparisonResults = compareInvoiceWithPO(invoiceData, poData);
    const riskAssessment = calculateRiskScore(comparisonResults);
    const explanation = generateExplanation(comparisonResults, riskAssessment);
    
    const status = riskAssessment.score < 30 ? 'VERIFIED' : 'FLAGGED';
    
    const verification = await prisma.verification.create({
      data: {
        invoiceId,
        poId,
        status,
        comparisonResults: JSON.stringify(comparisonResults),
        riskFactors: JSON.stringify(riskAssessment.factors || []),
        riskScore: riskAssessment.score,
        riskLevel: riskAssessment.level,
        aiExplanation: explanation
      }
    });
    
    await prisma.auditLog.create({
      data: {
        verificationId: verification.id,
        action: 'COMPARISON',
        actor: 'SYSTEM',
        details: 'Automated comparison completed',
        metadata: JSON.stringify({ score: riskAssessment.score })
      }
    });
    
    if (status === 'FLAGGED') {
      await prisma.auditLog.create({
        data: {
          verificationId: verification.id,
          action: 'FLAGGED',
          actor: 'SYSTEM',
          details: 'Verification flagged due to risk score',
          metadata: JSON.stringify({ score: riskAssessment.score })
        }
      });
    }
    
    return NextResponse.json(verification);
  } catch (error) {
    console.error('Error during verification:', error);
    return NextResponse.json({ error: 'Verification failed' }, { status: 500 });
  }
}
