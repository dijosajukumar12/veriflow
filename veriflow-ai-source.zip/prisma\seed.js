const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding VeriFlow AI database...');
  
  // Clear existing data
  await prisma.auditLog.deleteMany();
  await prisma.verification.deleteMany();
  await prisma.document.deleteMany();
  
  // ============================================================
  // SCENARIO 1: Perfect Match → LOW RISK (Score: 5)
  // ============================================================
  console.log('  Creating Scenario 1: Perfect Match (LOW RISK)...');
  
  const s1InvoiceData = {
    vendorName: 'TechFlow Solutions Pvt. Ltd.',
    invoiceNumber: 'INV-2026-001',
    invoiceDate: '2026-08-15',
    poNumber: 'PO-2026-001',
    currency: 'INR',
    lineItems: [
      { description: 'Dell Latitude 5540 Laptop', quantity: 10, unitPrice: 75000, total: 750000 }
    ],
    subtotal: 750000,
    tax: 135000,
    totalAmount: 885000
  };

  const s1POData = {
    vendorName: 'TechFlow Solutions Pvt. Ltd.',
    poNumber: 'PO-2026-001',
    poDate: '2026-08-10',
    lineItems: [
      { description: 'Dell Latitude 5540 Laptop', quantity: 10, approvedUnitPrice: 75000, total: 750000 }
    ],
    tax: 135000,
    totalApprovedAmount: 885000
  };

  const s1Invoice = await prisma.document.create({
    data: {
      type: 'INVOICE',
      filename: 'TechFlow_INV-2026-001.pdf',
      filePath: '/uploads/TechFlow_INV-2026-001.pdf',
      status: 'PROCESSED',
      rawText: 'INVOICE\nTechFlow Solutions Pvt. Ltd.\n123 Tech Park, Bangalore 560001\nGSTIN: 29AABCT1234F1ZP\n\nInvoice Number: INV-2026-001\nInvoice Date: 15-Aug-2026\nPO Reference: PO-2026-001\n\nBill To:\nAccurate Systems India Pvt. Ltd.\n\nItem Description          Qty    Unit Price     Amount\nDell Latitude 5540 Laptop  10    ₹75,000.00    ₹7,50,000.00\n\nSubtotal: ₹7,50,000.00\nGST (18%): ₹1,35,000.00\nTotal: ₹8,85,000.00',
      extractedData: JSON.stringify(s1InvoiceData)
    }
  });

  const s1PO = await prisma.document.create({
    data: {
      type: 'PURCHASE_ORDER',
      filename: 'TechFlow_PO-2026-001.pdf',
      filePath: '/uploads/TechFlow_PO-2026-001.pdf',
      status: 'PROCESSED',
      rawText: 'PURCHASE ORDER\nTechFlow Solutions Pvt. Ltd.\n123 Tech Park, Bangalore 560001\n\nPO Number: PO-2026-001\nPO Date: 10-Aug-2026\n\nItem Description          Qty    Approved Price    Amount\nDell Latitude 5540 Laptop  10    ₹75,000.00      ₹7,50,000.00\n\nSubtotal: ₹7,50,000.00\nGST (18%): ₹1,35,000.00\nTotal Approved Amount: ₹8,85,000.00',
      extractedData: JSON.stringify(s1POData)
    }
  });

  const s1ComparisonResults = [
    { field: 'Vendor Name', invoiceValue: 'TechFlow Solutions Pvt. Ltd.', poValue: 'TechFlow Solutions Pvt. Ltd.', status: 'MATCH', severity: 'low', explanation: 'Vendor names match exactly' },
    { field: 'PO Number', invoiceValue: 'PO-2026-001', poValue: 'PO-2026-001', status: 'MATCH', severity: 'low', explanation: 'PO numbers match exactly' },
    { field: 'Dell Latitude 5540 Laptop - Quantity', invoiceValue: 10, poValue: 10, status: 'MATCH', severity: 'low', explanation: 'Quantities match exactly' },
    { field: 'Dell Latitude 5540 Laptop - Unit Price', invoiceValue: 75000, poValue: 75000, status: 'MATCH', severity: 'low', explanation: 'Unit prices match exactly' },
    { field: 'Dell Latitude 5540 Laptop - Line Total', invoiceValue: 750000, poValue: 750000, status: 'MATCH', severity: 'low', explanation: 'Line totals match exactly' },
    { field: 'Tax Amount', invoiceValue: 135000, poValue: 135000, status: 'MATCH', severity: 'low', explanation: 'Tax amounts match exactly' },
    { field: 'Total Amount', invoiceValue: 885000, poValue: 885000, status: 'MATCH', severity: 'low', explanation: 'Total amounts match exactly' },
    { field: 'Arithmetic Check', invoiceValue: '₹7,50,000 + ₹1,35,000 = ₹8,85,000', poValue: '₹8,85,000', status: 'MATCH', severity: 'low', explanation: 'Invoice arithmetic is internally consistent' },
    { field: 'Date Sequence', invoiceValue: '2026-08-15', poValue: '2026-08-10', status: 'MATCH', severity: 'low', explanation: 'Invoice date (Aug 15) is after PO date (Aug 10) — correct sequence' }
  ];

  const s1RiskFactors = [
    { name: 'Vendor Mismatch', weight: 25, triggered: false, explanation: 'Vendor names match' },
    { name: 'PO Number Mismatch', weight: 20, triggered: false, explanation: 'PO numbers match' },
    { name: 'Total Amount Mismatch', weight: 20, triggered: false, explanation: 'Totals match' },
    { name: 'Quantity Mismatch', weight: 15, triggered: false, explanation: 'All quantities match' },
    { name: 'Unit Price Mismatch', weight: 10, triggered: false, explanation: 'All prices match' },
    { name: 'Arithmetic Inconsistency', weight: 15, triggered: false, explanation: 'Arithmetic is correct' },
    { name: 'Missing Fields', weight: 10, triggered: true, explanation: 'Minor: Currency field not explicitly stated in PO' },
    { name: 'Date Inconsistency', weight: 5, triggered: false, explanation: 'Dates are in correct sequence' }
  ];

  const s1Verification = await prisma.verification.create({
    data: {
      invoiceId: s1Invoice.id,
      poId: s1PO.id,
      status: 'VERIFIED',
      comparisonResults: JSON.stringify(s1ComparisonResults),
      riskFactors: JSON.stringify(s1RiskFactors),
      riskScore: 5,
      riskLevel: 'LOW',
      aiExplanation: 'LOW RISK: This invoice-PO pair shows an excellent match across all critical fields. The vendor name, PO number, quantities, unit prices, tax, and total amount are all consistent. The invoice arithmetic is internally correct (subtotal + tax = total). The invoice date (Aug 15, 2026) correctly follows the PO date (Aug 10, 2026). No discrepancies or risk signals detected. This verification can be auto-approved with high confidence.'
    }
  });

  await prisma.auditLog.createMany({
    data: [
      { verificationId: s1Verification.id, action: 'UPLOAD', actor: 'System', details: 'Invoice TechFlow_INV-2026-001.pdf uploaded and processed', metadata: JSON.stringify({ documentType: 'INVOICE' }), timestamp: new Date('2026-08-15T09:00:00Z') },
      { verificationId: s1Verification.id, action: 'UPLOAD', actor: 'System', details: 'Purchase Order TechFlow_PO-2026-001.pdf uploaded and processed', metadata: JSON.stringify({ documentType: 'PURCHASE_ORDER' }), timestamp: new Date('2026-08-15T09:00:05Z') },
      { verificationId: s1Verification.id, action: 'EXTRACTION', actor: 'System', details: 'Data extracted from both documents using OCR/regex engine', metadata: JSON.stringify({ method: 'regex' }), timestamp: new Date('2026-08-15T09:00:10Z') },
      { verificationId: s1Verification.id, action: 'COMPARISON', actor: 'System', details: 'Automated comparison completed. All fields match. Risk Score: 5/100 (LOW)', metadata: JSON.stringify({ riskScore: 5, riskLevel: 'LOW' }), timestamp: new Date('2026-08-15T09:00:15Z') },
      { verificationId: s1Verification.id, action: 'VERIFIED', actor: 'System', details: 'Document pair auto-verified due to low risk score', metadata: JSON.stringify({ autoApproved: true }), timestamp: new Date('2026-08-15T09:00:16Z') }
    ]
  });

  // ============================================================
  // SCENARIO 2: Minor Discrepancies → MEDIUM RISK (Score: 42)
  // ============================================================
  console.log('  Creating Scenario 2: Minor Discrepancies (MEDIUM RISK)...');

  const s2InvoiceData = {
    vendorName: 'Global Office Supplies',
    invoiceNumber: 'INV-2026-047',
    invoiceDate: '2026-08-18',
    poNumber: 'PO-2026-047',
    currency: 'INR',
    lineItems: [
      { description: 'Ergonomic Office Chair - ErgoMax Pro', quantity: 55, unitPrice: 4500, total: 247500 }
    ],
    subtotal: 247500,
    tax: 44550,
    totalAmount: 292050
  };

  const s2POData = {
    vendorName: 'Global Office Supplies',
    poNumber: 'PO-2026-047',
    poDate: '2026-08-12',
    lineItems: [
      { description: 'Ergonomic Office Chair - ErgoMax Pro', quantity: 50, approvedUnitPrice: 4500, total: 225000 }
    ],
    tax: 40500,
    totalApprovedAmount: 265500
  };

  const s2Invoice = await prisma.document.create({
    data: {
      type: 'INVOICE',
      filename: 'GlobalOffice_INV-2026-047.pdf',
      filePath: '/uploads/GlobalOffice_INV-2026-047.pdf',
      status: 'PROCESSED',
      rawText: 'INVOICE\nGlobal Office Supplies\n456 Commercial Avenue, Mumbai 400001\nGSTIN: 27AABCG5678H1ZQ\n\nInvoice Number: INV-2026-047\nInvoice Date: 18-Aug-2026\nPO Reference: PO-2026-047\n\nBill To:\nAccurate Systems India Pvt. Ltd.\n\nItem Description                    Qty    Unit Price     Amount\nErgonomic Office Chair - ErgoMax Pro 55    ₹4,500.00     ₹2,47,500.00\n\nSubtotal: ₹2,47,500.00\nGST (18%): ₹44,550.00\nTotal: ₹2,92,050.00',
      extractedData: JSON.stringify(s2InvoiceData)
    }
  });

  const s2PO = await prisma.document.create({
    data: {
      type: 'PURCHASE_ORDER',
      filename: 'GlobalOffice_PO-2026-047.pdf',
      filePath: '/uploads/GlobalOffice_PO-2026-047.pdf',
      status: 'PROCESSED',
      rawText: 'PURCHASE ORDER\nGlobal Office Supplies\n456 Commercial Avenue, Mumbai 400001\n\nPO Number: PO-2026-047\nPO Date: 12-Aug-2026\n\nItem Description                    Qty    Approved Price    Amount\nErgonomic Office Chair - ErgoMax Pro 50    ₹4,500.00        ₹2,25,000.00\n\nSubtotal: ₹2,25,000.00\nGST (18%): ₹40,500.00\nTotal Approved Amount: ₹2,65,500.00',
      extractedData: JSON.stringify(s2POData)
    }
  });

  const s2ComparisonResults = [
    { field: 'Vendor Name', invoiceValue: 'Global Office Supplies', poValue: 'Global Office Supplies', status: 'MATCH', severity: 'low', explanation: 'Vendor names match exactly' },
    { field: 'PO Number', invoiceValue: 'PO-2026-047', poValue: 'PO-2026-047', status: 'MATCH', severity: 'low', explanation: 'PO numbers match exactly' },
    { field: 'Ergonomic Office Chair - Quantity', invoiceValue: 55, poValue: 50, status: 'MISMATCH', severity: 'high', explanation: 'Invoice quantity (55) exceeds PO approved quantity (50) by 10%. This represents 5 additional units beyond the approved order.' },
    { field: 'Ergonomic Office Chair - Unit Price', invoiceValue: 4500, poValue: 4500, status: 'MATCH', severity: 'low', explanation: 'Unit prices match exactly at ₹4,500' },
    { field: 'Ergonomic Office Chair - Line Total', invoiceValue: 247500, poValue: 225000, status: 'MISMATCH', severity: 'high', explanation: 'Line total difference of ₹22,500 due to quantity mismatch' },
    { field: 'Tax Amount', invoiceValue: 44550, poValue: 40500, status: 'WARNING', severity: 'medium', explanation: 'Tax difference of ₹4,050 is proportional to the quantity/total difference' },
    { field: 'Total Amount', invoiceValue: 292050, poValue: 265500, status: 'MISMATCH', severity: 'high', explanation: 'Total invoice amount exceeds PO by ₹26,550 (10.0% over approved amount)' },
    { field: 'Arithmetic Check', invoiceValue: '₹2,47,500 + ₹44,550 = ₹2,92,050', poValue: '₹2,92,050', status: 'MATCH', severity: 'low', explanation: 'Invoice arithmetic is internally consistent' },
    { field: 'Date Sequence', invoiceValue: '2026-08-18', poValue: '2026-08-12', status: 'MATCH', severity: 'low', explanation: 'Invoice date follows PO date — correct sequence' }
  ];

  const s2RiskFactors = [
    { name: 'Vendor Mismatch', weight: 25, triggered: false, explanation: 'Vendor names match' },
    { name: 'PO Number Mismatch', weight: 20, triggered: false, explanation: 'PO numbers match' },
    { name: 'Total Amount Mismatch', weight: 20, triggered: true, explanation: 'Invoice total ₹2,92,050 exceeds PO total ₹2,65,500 by ₹26,550' },
    { name: 'Quantity Mismatch', weight: 15, triggered: true, explanation: 'Invoice qty 55 exceeds PO qty 50 by 5 units (10%)' },
    { name: 'Unit Price Mismatch', weight: 10, triggered: false, explanation: 'Unit prices match at ₹4,500' },
    { name: 'Arithmetic Inconsistency', weight: 15, triggered: false, explanation: 'Internal arithmetic is correct' },
    { name: 'Missing Fields', weight: 10, triggered: false, explanation: 'All expected fields present' },
    { name: 'Date Inconsistency', weight: 5, triggered: false, explanation: 'Date sequence is valid' }
  ];

  const s2Verification = await prisma.verification.create({
    data: {
      invoiceId: s2Invoice.id,
      poId: s2PO.id,
      status: 'FLAGGED',
      comparisonResults: JSON.stringify(s2ComparisonResults),
      riskFactors: JSON.stringify(s2RiskFactors),
      riskScore: 42,
      riskLevel: 'MEDIUM',
      aiExplanation: 'MEDIUM RISK: 2 discrepancies detected in this invoice-PO comparison. The invoice quantity for "Ergonomic Office Chair - ErgoMax Pro" is 55 units, which exceeds the PO-approved quantity of 50 units by 10% (5 additional chairs). This quantity overage cascades into a total amount mismatch — the invoice total of ₹2,92,050 exceeds the approved PO amount of ₹2,65,500 by ₹26,550. The vendor identity, PO number, and unit pricing are all consistent. The tax difference (₹4,050) is proportional to the quantity variance. Recommend manual review to confirm whether the additional 5 units were authorized via a separate approval or amendment.'
    }
  });

  await prisma.auditLog.createMany({
    data: [
      { verificationId: s2Verification.id, action: 'UPLOAD', actor: 'Admin', details: 'Invoice GlobalOffice_INV-2026-047.pdf uploaded', metadata: JSON.stringify({ documentType: 'INVOICE' }), timestamp: new Date('2026-08-18T14:30:00Z') },
      { verificationId: s2Verification.id, action: 'UPLOAD', actor: 'Admin', details: 'Purchase Order GlobalOffice_PO-2026-047.pdf uploaded', metadata: JSON.stringify({ documentType: 'PURCHASE_ORDER' }), timestamp: new Date('2026-08-18T14:30:05Z') },
      { verificationId: s2Verification.id, action: 'EXTRACTION', actor: 'System', details: 'Data extracted from both documents', metadata: JSON.stringify({ method: 'regex' }), timestamp: new Date('2026-08-18T14:30:12Z') },
      { verificationId: s2Verification.id, action: 'COMPARISON', actor: 'System', details: 'Comparison completed. 2 mismatches detected. Risk Score: 42/100 (MEDIUM)', metadata: JSON.stringify({ riskScore: 42, riskLevel: 'MEDIUM', mismatches: 2 }), timestamp: new Date('2026-08-18T14:30:15Z') },
      { verificationId: s2Verification.id, action: 'FLAGGED', actor: 'System', details: 'Document pair flagged for human review due to quantity and total amount discrepancies', metadata: JSON.stringify({ reason: 'Quantity exceeds PO by 10%' }), timestamp: new Date('2026-08-18T14:30:16Z') }
    ]
  });

  // ============================================================
  // SCENARIO 3: Major Mismatch → HIGH RISK (Score: 78)
  // ============================================================
  console.log('  Creating Scenario 3: Major Mismatch (HIGH RISK)...');

  const s3InvoiceData = {
    vendorName: 'Apex Digital',
    invoiceNumber: 'INV-8847',
    invoiceDate: '2026-08-20',
    poNumber: 'PO-2026-112',
    currency: 'INR',
    lineItems: [
      { description: 'Dell PowerEdge R750 Server', quantity: 8, unitPrice: 250000, total: 2000000 }
    ],
    subtotal: 2000000,
    tax: 360000,
    totalAmount: 2360000
  };

  const s3POData = {
    vendorName: 'Apex Digital Services',
    poNumber: 'PO-2026-113',
    poDate: '2026-08-05',
    lineItems: [
      { description: 'Dell PowerEdge R750 Server', quantity: 5, approvedUnitPrice: 225000, total: 1125000 }
    ],
    tax: 202500,
    totalApprovedAmount: 1327500
  };

  const s3Invoice = await prisma.document.create({
    data: {
      type: 'INVOICE',
      filename: 'ApexDigital_INV-8847.pdf',
      filePath: '/uploads/ApexDigital_INV-8847.pdf',
      status: 'PROCESSED',
      rawText: 'INVOICE\nApex Digital\n789 IT Hub, Hyderabad 500032\nGSTIN: 36AABCA9012D1ZR\n\nInvoice Number: INV-8847\nInvoice Date: 20-Aug-2026\nPO Reference: PO-2026-112\n\nBill To:\nAccurate Systems India Pvt. Ltd.\n\nItem Description              Qty    Unit Price       Amount\nDell PowerEdge R750 Server     8     ₹2,50,000.00    ₹20,00,000.00\n\nSubtotal: ₹20,00,000.00\nGST (18%): ₹3,60,000.00\nTotal: ₹23,60,000.00',
      extractedData: JSON.stringify(s3InvoiceData)
    }
  });

  const s3PO = await prisma.document.create({
    data: {
      type: 'PURCHASE_ORDER',
      filename: 'ApexDigital_PO-2026-113.pdf',
      filePath: '/uploads/ApexDigital_PO-2026-113.pdf',
      status: 'PROCESSED',
      rawText: 'PURCHASE ORDER\nApex Digital Services\n789 IT Hub, Hyderabad 500032\n\nPO Number: PO-2026-113\nPO Date: 05-Aug-2026\n\nItem Description              Qty    Approved Price     Amount\nDell PowerEdge R750 Server     5     ₹2,25,000.00      ₹11,25,000.00\n\nSubtotal: ₹11,25,000.00\nGST (18%): ₹2,02,500.00\nTotal Approved Amount: ₹13,27,500.00',
      extractedData: JSON.stringify(s3POData)
    }
  });

  const s3ComparisonResults = [
    { field: 'Vendor Name', invoiceValue: 'Apex Digital', poValue: 'Apex Digital Services', status: 'WARNING', severity: 'medium', explanation: 'Vendor names differ — "Apex Digital" vs "Apex Digital Services". Possible abbreviation, but could indicate a different entity.' },
    { field: 'PO Number', invoiceValue: 'PO-2026-112', poValue: 'PO-2026-113', status: 'MISMATCH', severity: 'critical', explanation: 'CRITICAL: PO numbers do not match. Invoice references PO-2026-112 but the provided PO is PO-2026-113. This may indicate the wrong PO was submitted or the invoice references a different order.' },
    { field: 'PowerEdge R750 Server - Quantity', invoiceValue: 8, poValue: 5, status: 'MISMATCH', severity: 'critical', explanation: 'CRITICAL: Invoice quantity (8) exceeds PO approved quantity (5) by 60%. This represents 3 additional servers worth ₹7,50,000 in unauthorized billing.' },
    { field: 'PowerEdge R750 Server - Unit Price', invoiceValue: 250000, poValue: 225000, status: 'MISMATCH', severity: 'high', explanation: 'Invoice unit price (₹2,50,000) exceeds PO approved price (₹2,25,000) by ₹25,000 per unit (11.1% markup)' },
    { field: 'PowerEdge R750 Server - Line Total', invoiceValue: 2000000, poValue: 1125000, status: 'MISMATCH', severity: 'critical', explanation: 'Line total difference of ₹8,75,000 due to both quantity and price increases' },
    { field: 'Tax Amount', invoiceValue: 360000, poValue: 202500, status: 'MISMATCH', severity: 'high', explanation: 'Tax difference of ₹1,57,500 — proportional to the inflated total' },
    { field: 'Total Amount', invoiceValue: 2360000, poValue: 1327500, status: 'MISMATCH', severity: 'critical', explanation: 'CRITICAL: Invoice total ₹23,60,000 exceeds PO total ₹13,27,500 by ₹10,32,500 (77.8% over approved amount)' },
    { field: 'Arithmetic Check', invoiceValue: '₹20,00,000 + ₹3,60,000 = ₹23,60,000', poValue: '₹23,60,000', status: 'MATCH', severity: 'low', explanation: 'Invoice arithmetic is internally consistent' },
    { field: 'Date Sequence', invoiceValue: '2026-08-20', poValue: '2026-08-05', status: 'MATCH', severity: 'low', explanation: 'Invoice date follows PO date — correct sequence' }
  ];

  const s3RiskFactors = [
    { name: 'Vendor Mismatch', weight: 25, triggered: true, explanation: 'Vendor names differ: "Apex Digital" vs "Apex Digital Services"' },
    { name: 'PO Number Mismatch', weight: 20, triggered: true, explanation: 'PO numbers don\'t match: PO-2026-112 vs PO-2026-113' },
    { name: 'Total Amount Mismatch', weight: 20, triggered: true, explanation: 'Invoice total exceeds PO by ₹10,32,500 (77.8%)' },
    { name: 'Quantity Mismatch', weight: 15, triggered: true, explanation: 'Quantity 8 vs 5 — 60% overage' },
    { name: 'Unit Price Mismatch', weight: 10, triggered: true, explanation: 'Price ₹2,50,000 vs ₹2,25,000 — 11.1% markup' },
    { name: 'Arithmetic Inconsistency', weight: 15, triggered: false, explanation: 'Internal arithmetic is correct' },
    { name: 'Duplicate Invoice Number', weight: 15, triggered: false, explanation: 'Invoice number INV-8847 not seen before' },
    { name: 'Missing Fields', weight: 10, triggered: false, explanation: 'All expected fields present' },
    { name: 'Date Inconsistency', weight: 5, triggered: false, explanation: 'Date sequence is valid' }
  ];

  const s3Verification = await prisma.verification.create({
    data: {
      invoiceId: s3Invoice.id,
      poId: s3PO.id,
      status: 'FLAGGED',
      comparisonResults: JSON.stringify(s3ComparisonResults),
      riskFactors: JSON.stringify(s3RiskFactors),
      riskScore: 78,
      riskLevel: 'HIGH',
      aiExplanation: 'HIGH RISK: Multiple critical discrepancies detected in this invoice-PO comparison requiring immediate investigation.\n\n1. PO NUMBER MISMATCH: The invoice references PO-2026-112, but the submitted purchase order is PO-2026-113. This is a fundamental identity mismatch — the invoice may correspond to a different order entirely.\n\n2. VENDOR NAME VARIANCE: The invoice vendor is "Apex Digital" while the PO lists "Apex Digital Services". This could be an abbreviation or may indicate different legal entities.\n\n3. QUANTITY OVERBILLING (60%): The invoice bills for 8 Dell PowerEdge R750 Servers, but only 5 were approved in the PO. The 3 additional servers represent ₹7,50,000 in unauthorized charges at the PO price, or ₹7,50,000+ at the inflated invoice price.\n\n4. UNIT PRICE INFLATION (11.1%): Each server is billed at ₹2,50,000 vs the approved ₹2,25,000, an unauthorized markup of ₹25,000 per unit.\n\n5. TOTAL OVERCHARGE: The combined effect of quantity and price inflation results in a total invoice of ₹23,60,000 vs the approved ₹13,27,500 — an excess of ₹10,32,500 (77.8% over the approved amount).\n\nRecommendation: Reject this invoice and request the vendor to resubmit with the correct PO reference, approved quantities, and negotiated pricing.'
    }
  });

  await prisma.auditLog.createMany({
    data: [
      { verificationId: s3Verification.id, action: 'UPLOAD', actor: 'Admin', details: 'Invoice ApexDigital_INV-8847.pdf uploaded', metadata: JSON.stringify({ documentType: 'INVOICE' }), timestamp: new Date('2026-08-20T11:15:00Z') },
      { verificationId: s3Verification.id, action: 'UPLOAD', actor: 'Admin', details: 'Purchase Order ApexDigital_PO-2026-113.pdf uploaded', metadata: JSON.stringify({ documentType: 'PURCHASE_ORDER' }), timestamp: new Date('2026-08-20T11:15:05Z') },
      { verificationId: s3Verification.id, action: 'EXTRACTION', actor: 'System', details: 'Data extracted from both documents', metadata: JSON.stringify({ method: 'regex' }), timestamp: new Date('2026-08-20T11:15:12Z') },
      { verificationId: s3Verification.id, action: 'COMPARISON', actor: 'System', details: 'Comparison completed. 6 mismatches and 1 warning detected. Risk Score: 78/100 (HIGH)', metadata: JSON.stringify({ riskScore: 78, riskLevel: 'HIGH', mismatches: 6, warnings: 1 }), timestamp: new Date('2026-08-20T11:15:18Z') },
      { verificationId: s3Verification.id, action: 'FLAGGED', actor: 'System', details: 'CRITICAL: Document pair flagged for immediate investigation — PO number mismatch, 60% quantity overage, 11.1% price inflation, 77.8% total overcharge', metadata: JSON.stringify({ criticalIssues: ['PO mismatch', 'Quantity overbilling', 'Price inflation'] }), timestamp: new Date('2026-08-20T11:15:19Z') }
    ]
  });

  // Print summary
  const docCount = await prisma.document.count();
  const verCount = await prisma.verification.count();
  const auditCount = await prisma.auditLog.count();
  
  console.log('');
  console.log('✅ Seed complete!');
  console.log(`   📄 ${docCount} documents created`);
  console.log(`   🔍 ${verCount} verifications created`);
  console.log(`   📋 ${auditCount} audit log entries created`);
  console.log('');
  console.log('   Scenarios:');
  console.log('   1. TechFlow Solutions — Perfect Match → LOW RISK (5/100)');
  console.log('   2. Global Office Supplies — Qty Mismatch → MEDIUM RISK (42/100)');
  console.log('   3. Apex Digital — Major Mismatch → HIGH RISK (78/100)');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
