import prisma from '@/lib/db';
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const totalDocuments = await prisma.document.count();
    const totalVerifications = await prisma.verification.count();
    
    const verifications = await prisma.verification.findMany();
    const statusCounts = {
      verified: verifications.filter(v => v.status === 'VERIFIED').length,
      flagged: verifications.filter(v => v.status === 'FLAGGED').length,
      underReview: verifications.filter(v => v.status === 'UNDER_REVIEW').length,
      approved: verifications.filter(v => v.status === 'APPROVED').length,
      rejected: verifications.filter(v => v.status === 'REJECTED').length,
    };
    
    const riskDistribution = {
      low: verifications.filter(v => v.riskLevel === 'LOW').length,
      medium: verifications.filter(v => v.riskLevel === 'MEDIUM').length,
      high: verifications.filter(v => v.riskLevel === 'HIGH').length,
    };
    
    const recentActivity = await prisma.auditLog.findMany({
      take: 10,
      orderBy: { timestamp: 'desc' }
    });
    
    if (recentActivity.length > 0) {
      const verificationsForLogs = await prisma.verification.findMany({
        where: { id: { in: [...new Set(recentActivity.map(l => l.verificationId))] } }
      });
      recentActivity.forEach(log => {
        log.verification = verificationsForLogs.find(v => v.id === log.verificationId);
      });
    }

    return NextResponse.json({
      totalDocuments,
      totalVerifications,
      statusCounts,
      riskDistribution,
      recentActivity
    });
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    return NextResponse.json({ error: 'Failed to fetch dashboard stats' }, { status: 500 });
  }
}
