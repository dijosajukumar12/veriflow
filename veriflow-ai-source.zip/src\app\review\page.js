'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { AlertTriangle, Check, X, FileText, ArrowRight } from 'lucide-react';

export default function ReviewQueue() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchReviews = async () => {
    try {
      const res = await fetch('/api/review');
      if (res.ok) {
        const data = await res.json();
        setItems(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReviews();
  }, []);

  const handleAction = async (id, action) => {
    try {
      const res = await fetch('/api/review', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          verificationId: id,
          action,
          actor: 'Admin',
          comments: `Manually ${action.toLowerCase()}d from Review Queue`
        })
      });
      if (res.ok) {
        fetchReviews();
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) {
    return (
      <div>
        <div className="page-header">
          <h1 className="page-title">Review Queue</h1>
          <p className="page-subtitle">Documents requiring human review</p>
        </div>
        <div className="grid grid-cols-1 gap-4 max-w-4xl">
          {[1,2,3].map(i => <div key={i} className="skeleton skeleton-card"></div>)}
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Review Queue</h1>
        <p className="page-subtitle">Documents requiring human review</p>
      </div>

      {items.length === 0 ? (
        <div className="card text-center py-12">
          <Check size={48} className="text-success mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">All caught up!</h2>
          <p className="text-secondary">There are no documents pending manual review at this time.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 max-w-4xl">
          {items.map(item => {
            const riskFactors = item.riskFactors ? JSON.parse(item.riskFactors) : [];
            const criticalMismatch = riskFactors.find(f => f.triggered) || { explanation: 'Multiple discrepancies found' };

            return (
              <div key={item.id} className="card p-5 flex items-center justify-between hover:shadow-md transition-shadow">
                <div className="flex items-center gap-6">
                  <div className="flex flex-col items-center justify-center w-16 h-16 rounded-full border-4" style={{borderColor: item.riskScore > 80 ? 'var(--danger)' : 'var(--warning)', color: item.riskScore > 80 ? 'var(--danger)' : 'var(--warning)'}}>
                    <span className="font-bold text-xl">{item.riskScore}</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <span className="font-semibold">{item.invoice?.filename || 'Unknown Invoice'}</span>
                      <ArrowRight size={14} className="text-secondary" />
                      <span className="font-semibold">{item.po?.filename || 'Unknown PO'}</span>
                      <span className="text-xs text-secondary ml-2">• {new Date(item.createdAt).toLocaleDateString()}</span>
                    </div>
                    <div className="text-sm flex items-center gap-2 text-danger">
                      <AlertTriangle size={14} /> Critical: {criticalMismatch.explanation}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Link href={`/verification/${item.id}`} className="btn btn-outline py-2">
                    View Details
                  </Link>
                  <button className="btn btn-success py-2 px-3" title="Approve" onClick={() => handleAction(item.id, 'APPROVE')}>
                    <Check size={18} />
                  </button>
                  <button className="btn btn-danger py-2 px-3" title="Reject" onClick={() => handleAction(item.id, 'REJECT')}>
                    <X size={18} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
