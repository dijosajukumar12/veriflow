import prisma from '@/lib/db';
import { NextResponse } from 'next/server';

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const verificationId = searchParams.get('verificationId');
    
    const where = verificationId ? { verificationId } : {};
    
    const auditLogs = await prisma.auditLog.findMany({
      where,
      orderBy: { timestamp: 'desc' }
    });
    
    if (auditLogs.length > 0) {
      const verifications = await prisma.verification.findMany({
        where: {
          id: { in: [...new Set(auditLogs.map(l => l.verificationId))] }
        }
      });
      
      const mappedLogs = auditLogs.map(log => ({
        ...log,
        verification: verifications.find(v => v.id === log.verificationId)
      }));
      
      return NextResponse.json(mappedLogs);
    }
    
    return NextResponse.json(auditLogs);
  } catch (error) {
    console.error('Error fetching audit logs:', error);
    return NextResponse.json({ error: 'Failed to fetch audit logs' }, { status: 500 });
  }
}
