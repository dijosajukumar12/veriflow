'use client';

import { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { FileText, CheckCircle, AlertTriangle, Clock } from 'lucide-react';

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate fetching from /api/dashboard
    setTimeout(() => {
      setData({
        stats: { total: 12450, verified: 9820, flagged: 1430, pending: 1200 },
        riskDistribution: [
          { name: 'Low Risk', value: 8500, color: '#10b981' },
          { name: 'Medium Risk', value: 2500, color: '#f59e0b' },
          { name: 'High Risk', value: 1450, color: '#ef4444' },
        ],
        recentActivity: [
          { id: 1, action: 'VERIFIED', doc: 'INV-2023-001', time: '10 mins ago', user: 'System AI' },
          { id: 2, action: 'FLAGGED', doc: 'PO-99234', time: '45 mins ago', user: 'System AI' },
          { id: 3, action: 'APPROVED', doc: 'INV-2023-089', time: '2 hours ago', user: 'Sarah Jenkins' },
          { id: 4, action: 'REJECTED', doc: 'INV-2023-112', time: '3 hours ago', user: 'Mike Ross' },
        ]
      });
      setLoading(false);
    }, 1000);
  }, []);

  if (loading) {
    return (
      <div>
        <div className="page-header">
          <h1 className="page-title">Dashboard</h1>
          <p className="page-subtitle">Document verification overview</p>
        </div>
        <div className="grid grid-cols-4 mb-6">
          {[1,2,3,4].map(i => <div key={i} className="skeleton skeleton-card"></div>)}
        </div>
        <div className="grid grid-cols-2">
          <div className="skeleton skeleton-card" style={{height: '300px'}}></div>
          <div className="skeleton skeleton-card" style={{height: '300px'}}></div>
        </div>
      </div>
    );
  }

  const formatNumber = (num) => new Intl.NumberFormat('en-IN').format(num);

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Dashboard</h1>
        <p className="page-subtitle">Document verification overview</p>
      </div>

      <div className="grid grid-cols-4 mb-6">
        <div className="card">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-blue-50" style={{backgroundColor: '#eff6ff', color: 'var(--primary)'}}>
              <FileText size={20} />
            </div>
            <div className="text-secondary font-medium">Total Processed</div>
          </div>
          <div className="text-3xl font-bold">{formatNumber(data.stats.total)}</div>
        </div>
        <div className="card">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-emerald-50" style={{backgroundColor: '#ecfdf5', color: 'var(--success)'}}>
              <CheckCircle size={20} />
            </div>
            <div className="text-secondary font-medium">Verified</div>
          </div>
          <div className="text-3xl font-bold">{formatNumber(data.stats.verified)}</div>
        </div>
        <div className="card">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-rose-50" style={{backgroundColor: '#fef2f2', color: 'var(--danger)'}}>
              <AlertTriangle size={20} />
            </div>
            <div className="text-secondary font-medium">Flagged</div>
          </div>
          <div className="text-3xl font-bold">{formatNumber(data.stats.flagged)}</div>
        </div>
        <div className="card">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-amber-50" style={{backgroundColor: '#fffbeb', color: 'var(--warning)'}}>
              <Clock size={20} />
            </div>
            <div className="text-secondary font-medium">Pending Review</div>
          </div>
          <div className="text-3xl font-bold">{formatNumber(data.stats.pending)}</div>
        </div>
      </div>

      <div className="grid grid-cols-2">
        <div className="card">
          <h2 className="card-title">Risk Distribution</h2>
          <div style={{ height: 250 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data.riskDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {data.riskDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => formatNumber(value)} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-4 mt-4">
            {data.riskDistribution.map(item => (
              <div key={item.name} className="flex items-center gap-2 text-sm">
                <div style={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: item.color }}></div>
                {item.name}
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <h2 className="card-title">Recent Activity</h2>
          <div className="flex flex-col gap-4">
            {data.recentActivity.map(activity => (
              <div key={activity.id} className="flex items-center justify-between border-b pb-3" style={{borderColor: 'var(--border)'}}>
                <div>
                  <div className="font-medium">{activity.doc}</div>
                  <div className="text-sm text-secondary flex items-center gap-2 mt-1">
                    <Clock size={14} /> {activity.time} • {activity.user}
                  </div>
                </div>
                <span className={`badge badge-${
                  activity.action === 'VERIFIED' || activity.action === 'APPROVED' ? 'success' :
                  activity.action === 'FLAGGED' ? 'warning' : 'danger'
                }`}>
                  {activity.action}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
