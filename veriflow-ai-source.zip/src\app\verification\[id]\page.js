'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Check, X, AlertTriangle, FileText, ArrowRight, Activity, ShieldCheck, History } from 'lucide-react';

export default function VerificationDetails({ params }) {
  const router = useRouter();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  // Unwrap params using React.use() equivalent pattern for Next 13+ client components
  const id = params?.id;

  useEffect(() => {
    if (!id) return;
    const fetchDetails = async () => {
      try {
        const res = await fetch(`/api/verify/${id}`);
        if (res.ok) {
          const result = await res.json();
          setData(result);
        }
      } catch (err) {
        console.error('Failed to fetch verification details:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchDetails();
  }, [id]);

  const handleAction = async (action) => {
    try {
      const res = await fetch('/api/review', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          verificationId: id,
          action,
          actor: 'Admin',
          comments: `Manually ${action.toLowerCase()}d from Verification Details`
        })
      });
      if (res.ok) {
        router.refresh(); // Or re-fetch data
        window.location.reload();
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (loading || !data) {
    return (
      <div className="p-4">
        <div className="skeleton skeleton-title"></div>
        <div className="skeleton skeleton-text"></div>
        <div className="mt-8 skeleton skeleton-card"></div>
      </div>
    );
  }

  const getGaugeColor = (score) => {
    if (score < 30) return 'var(--success)';
    if (score < 70) return 'var(--warning)';
    return 'var(--danger)';
  };

  const getStatusBadge = (status) => {
    switch(status) {
      case 'MATCH': return <span className="badge badge-success">Match</span>;
      case 'MISMATCH': return <span className="badge badge-danger">Mismatch</span>;
      case 'WARNING': return <span className="badge badge-warning">Warning</span>;
      default: return <span className="badge badge-neutral">{status}</span>;
    }
  };

  const dashArray = 2 * Math.PI * 90;
  const dashOffset = dashArray - (dashArray * data.riskScore) / 100;

  return (
    <div>
      <div className="page-header flex justify-between items-start">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="page-title m-0">Verification Result</h1>
            <span className={`badge ${data.riskLevel === 'HIGH' ? 'badge-danger' : data.riskLevel === 'MEDIUM' ? 'badge-warning' : 'badge-success'}`}>
              {data.status}
            </span>
          </div>
          <p className="page-subtitle">ID: {data.id}</p>
        </div>
        
        {(data.status === 'FLAGGED' || data.status === 'UNDER_REVIEW') && (
          <div className="flex gap-3">
            <button className="btn btn-danger" onClick={() => handleAction('REJECT')}><X size={18} /> Reject</button>
            <button className="btn btn-warning" onClick={() => handleAction('REVIEW')}><AlertTriangle size={18} /> Request Review</button>
            <button className="btn btn-success" onClick={() => handleAction('APPROVE')}><Check size={18} /> Force Approve</button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-3 mb-6">
        <div className="card flex flex-col items-center justify-center">
          <h3 className="font-semibold text-secondary mb-4 uppercase tracking-wider text-sm">AI Risk Score</h3>
          <div className="risk-gauge-container">
            <svg className="risk-gauge-svg" viewBox="0 0 200 200">
              <circle className="risk-gauge-bg" cx="100" cy="100" r="90" />
              <circle 
                className="risk-gauge-progress" 
                cx="100" cy="100" r="90" 
                stroke={getGaugeColor(data.riskScore)}
                strokeDasharray={dashArray}
                strokeDashoffset={dashOffset}
              />
            </svg>
            <div className="risk-gauge-text">
              <div className="risk-gauge-score" style={{color: getGaugeColor(data.riskScore)}}>{data.riskScore}</div>
              <div className="risk-gauge-label">/ 100</div>
            </div>
          </div>
          <div className="mt-4 font-semibold" style={{color: getGaugeColor(data.riskScore)}}>
            {data.riskLevel} RISK
          </div>
        </div>

        <div className="card col-span-2 flex flex-col justify-center border-l-4" style={{borderLeftColor: getGaugeColor(data.riskScore)}}>
          <h2 className="card-title"><Activity size={20} className="text-secondary" /> AI Assessment</h2>
          <p className="text-lg leading-relaxed whitespace-pre-wrap">{data.aiExplanation}</p>
          
          <div className="mt-6 flex gap-4">
            <div className="flex-1 bg-slate-50 p-4 rounded-lg border">
              <div className="text-xs font-semibold text-secondary uppercase mb-1">Invoice</div>
              <div className="font-medium flex items-center gap-2"><FileText size={14}/> {data.invoice?.filename || 'Unknown'}</div>
            </div>
            <div className="flex items-center text-secondary"><ArrowRight size={20} /></div>
            <div className="flex-1 bg-slate-50 p-4 rounded-lg border">
              <div className="text-xs font-semibold text-secondary uppercase mb-1">Purchase Order</div>
              <div className="font-medium flex items-center gap-2"><FileText size={14}/> {data.po?.filename || 'Unknown'}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6 mb-6">
        <div className="col-span-2 card p-0 overflow-hidden">
          <div className="p-4 border-b border-border bg-slate-50">
            <h2 className="font-semibold text-lg m-0 flex items-center gap-2"><ShieldCheck size={20} className="text-primary"/> Field-by-Field Comparison</h2>
          </div>
          <div className="table-container border-0 border-radius-0">
            <table>
              <thead>
                <tr>
                  <th>Field</th>
                  <th>Invoice Value</th>
                  <th>PO Value</th>
                  <th>Status</th>
                  <th>AI Notes</th>
                </tr>
              </thead>
              <tbody>
                {(data.comparisonResults || []).map((f, i) => (
                  <tr key={i}>
                    <td className="font-medium">{f.field}</td>
                    <td>{f.invoiceValue}</td>
                    <td>{f.poValue}</td>
                    <td>{getStatusBadge(f.status)}</td>
                    <td className="text-sm text-secondary">{f.explanation}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <h2 className="card-title"><AlertTriangle size={20} className="text-secondary" /> Risk Factors</h2>
          <div className="flex flex-col gap-3">
            {(data.riskFactors || []).map((factor, i) => (
              <div key={i} className={`p-3 rounded-lg border flex items-center justify-between ${factor.triggered ? 'bg-red-50 border-red-100 text-red-900' : 'bg-slate-50 border-slate-100 text-slate-400'}`}>
                <span className="font-medium text-sm">{factor.name}</span>
                {factor.triggered ? <AlertTriangle size={16} className="text-red-500" /> : <Check size={16} />}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
