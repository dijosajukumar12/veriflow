'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { History, Search, FileText, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

export default function AuditTrail() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setLogs([
        { id: 1, type: 'MANUAL_APPROVAL', user: 'Sarah Jenkins', doc: 'v-12345', inv: 'INV-2023-001', time: 'Aug 21, 2026, 11:45 AM', detail: 'Approved with note: Variance within acceptable threshold.' },
        { id: 2, type: 'SYSTEM_FLAGGED', user: 'VeriFlow AI', doc: 'v-12346', inv: 'INV-2023-002', time: 'Aug 21, 2026, 11:30 AM', detail: 'Flagged due to 18% amount variance.' },
        { id: 3, type: 'DOCUMENT_UPLOADED', user: 'API Agent', doc: 'v-12346', inv: 'INV-2023-002', time: 'Aug 21, 2026, 11:28 AM', detail: 'Received invoice and PO via API integration.' },
        { id: 4, type: 'MANUAL_REJECTION', user: 'Mike Ross', doc: 'v-12340', inv: 'INV-2023-008', time: 'Aug 20, 2026, 15:20 PM', detail: 'Rejected. Suspected fraudulent vendor details.' },
        { id: 5, type: 'SYSTEM_VERIFIED', user: 'VeriFlow AI', doc: 'v-12339', inv: 'INV-2023-009', time: 'Aug 20, 2026, 14:10 PM', detail: 'Perfect match. Auto-verified.' },
      ]);
      setLoading(false);
    }, 800);
  }, []);

  const getIcon = (type) => {
    if (type.includes('APPROVAL') || type.includes('VERIFIED')) return <CheckCircle size={16} className="text-success" />;
    if (type.includes('REJECTION')) return <XCircle size={16} className="text-danger" />;
    if (type.includes('FLAGGED')) return <AlertTriangle size={16} className="text-warning" />;
    return <FileText size={16} className="text-primary" />;
  };

  return (
    <div>
      <div className="page-header flex justify-between items-end">
        <div>
          <h1 className="page-title">Audit Trail</h1>
          <p className="page-subtitle">Complete verification activity log</p>
        </div>
        <div className="relative w-64">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary" size={18} />
          <input type="text" placeholder="Search logs..." className="form-input pl-10" />
        </div>
      </div>

      <div className="card p-6">
        {loading ? (
          <div>
            {[1,2,3].map(i => <div key={i} className="skeleton skeleton-text mb-6" style={{height: 60}}></div>)}
          </div>
        ) : (
          <div className="relative border-l-2 border-border ml-3 pl-6 py-2 flex flex-col gap-8">
            {logs.map(log => (
              <div key={log.id} className="relative">
                <div className="absolute -left-[35px] top-1 bg-white p-1 rounded-full border border-border">
                  {getIcon(log.type)}
                </div>
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-3">
                    <span className="font-semibold text-sm">{log.user}</span>
                    <span className="text-xs text-secondary">{log.time}</span>
                  </div>
                  <div className="text-sm mt-1">
                    <span className="badge badge-neutral mr-2" style={{fontSize: '0.65rem'}}>{log.type.replace('_', ' ')}</span>
                    <Link href={`/verification/${log.doc}`} className="font-medium text-primary hover:underline">
                      {log.inv}
                    </Link>
                  </div>
                  <p className="text-sm text-secondary mt-1 bg-slate-50 p-2 rounded border border-border inline-block max-w-2xl">
                    {log.detail}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
